
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "socks5",
                host: "209.127.191.180",
                port: parseInt(9279)
            },
            bypassList: ["localhost"]
            }
        };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
    function callbackFn(details) {
        return {
            authCredentials: {
                username: "",
                password: ""
            }
        };
    }
    
    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    