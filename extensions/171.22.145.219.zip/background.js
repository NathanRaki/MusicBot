
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "socks5",
                host: "171.22.145.219",
                port: parseInt(1080)
            },
            bypassList: ["localhost"]
            }
        };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
    function callbackFn(details) {
        return {
            authCredentials: {
                username: "hnksebno-dest",
                password: "hy6y2cztxgp1"
            }
        };
    }
    
    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    