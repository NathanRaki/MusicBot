
    var config = {
            mode: "fixed_servers",
            rules: {
            singleProxy: {
                scheme: "socks5",
                host: "45.95.96.132",
                port: parseInt(8691)
            },
            bypassList: ["localhost"]
            }
        };
    
    chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
    
    function callbackFn(details) {
        return {
            authCredentials: {
                username: "",
                password: ""
            }
        };
    }
    
    chrome.webRequest.onAuthRequired.addListener(
                callbackFn,
                {urls: ["<all_urls>"]},
                ['blocking']
    );
    